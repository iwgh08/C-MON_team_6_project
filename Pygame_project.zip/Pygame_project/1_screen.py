import pygame
import sys

pygame.init()

# 화면 설정
screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("전설이 된 농부")

background_img = pygame.image.load("C:\\Users\\minih\\Desktop\\Pygame_project\\background.png").convert()
background_img = pygame.transform.scale(background_img, (screen_width, screen_height))

# 색상
WHITE = (255, 255, 255)
GREEN = (50, 200, 50)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
ORANGE = (155, 127, 0)
YELLOW = (250, 237, 39)

# 시계
clock = pygame.time.Clock()
FPS = 60

# 플레이어 속성
player_img = pygame.image.load("C:\\Users\\minih\\Desktop\\Pygame_project\\player.png")
player_hp = 100
player_max_hp = 100
player_width, player_height = player_img.get_rect().size
player_x, player_y = 100, 100
player_vel_y = 0
gravity = 0.5
jump_power = 10
player_on_ground = False
last_direction = "RIGHT"
player_state = True
evasion = False

# 몬스터 속성
monster_img = pygame.image.load("C:\\Users\\minih\\Desktop\\Pygame_project\\enemy.png")
monster_hp = 100
monster_max_hp = 100
monster_width, monster_height = monster_img.get_rect().size
monster_x, monster_y = 1100, 400
monster_vel_y = 0
monster_on_ground = False
monster_state = True

# 무기 속성
weapon_img = pygame.image.load("C:\\Users\\minih\\Desktop\\Pygame_project\\weapon.png")
weapon_width, weapon_height = weapon_img.get_rect().size
weapon_x, weapon_y = 400, screen_height - (weapon_height + 40)
weapon_collected = False
weapon_equipped = False



# 발판 리스트
platforms = [
    pygame.Rect(0, screen_height - 40, screen_width, 40),
    pygame.Rect(200, 600, 100, 20),
    pygame.Rect(400, 500, 100, 20),
    pygame.Rect(600, 400, 100, 20),
    pygame.Rect(800, 300, 100, 20),
]

# 몬스터 체력 바
def draw_monster_health_bar(screen, x, y, hp, max_hp, width = monster_width, height = 5):
    # HP 비율
    ratio = hp / max_hp
    # 체력바 테두리
    pygame.draw.rect(screen, BLACK, (x, y - 10, width, height))
    # 현재 체력
    if hp >= max_hp * 3/4:
        pygame.draw.rect(screen, GREEN, (x, y - 10, width * ratio, height))
    elif hp >= max_hp * 1/2:
        pygame.draw.rect(screen, ORANGE, (x, y - 10, width * ratio, height))
    elif hp >= max_hp * 1/4:
        pygame.draw.rect(screen, YELLOW, (x, y - 10, width * ratio, height))
    else:
        pygame.draw.rect(screen, RED, (x, y - 10, width * ratio, height))


def draw_player_health_bar(screen, x, y, hp, max_hp, width = 500, height = 10):
    # HP 비율
    ratio = hp / max_hp
    # 체력바 테두리
    pygame.draw.rect(screen, BLACK, (x, y - 10, width, height))
    # 현재 체력
    if hp >= max_hp * 3/4:
        pygame.draw.rect(screen, GREEN, (x, y - 10, width * ratio, height))
    elif hp >= max_hp * 1/2:
        pygame.draw.rect(screen, ORANGE, (x, y - 10, width * ratio, height))
    elif hp >= max_hp * 1/4:
        pygame.draw.rect(screen, YELLOW, (x, y - 10, width * ratio, height))
    else:
        pygame.draw.rect(screen, RED, (x, y - 10, width * ratio, height))
    


# 메인 루프
running = True
while running:
    # 키 입력
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        player_x -= 5
        last_direction = "LEFT"
    if keys[pygame.K_d]:
        player_x += 5
        last_direction = "RIGHT"
    if keys[pygame.K_SPACE] and player_on_ground:
        player_vel_y = -jump_power
        player_on_ground = False

    # 중력 적용
    player_vel_y += gravity
    player_y += player_vel_y

    monster_vel_y += gravity
    monster_y += monster_vel_y

    # 플레이어 & 몬스터 rect
    player_rect = pygame.Rect(player_x, player_y, player_width, player_height)
    monster_rect = pygame.Rect(monster_x, monster_y, monster_width, monster_height)
    weapon_rect = pygame.Rect(weapon_x, weapon_y, *weapon_img.get_size())

    # 발판 충돌 체크
    player_on_ground = False
    monster_on_ground = False
    for plat in platforms:
        if player_rect.colliderect(plat) and player_vel_y >= 0:
            player_y = plat.top - player_height
            player_vel_y = 0
            player_on_ground = True

        if monster_rect.colliderect(plat) and monster_vel_y >= 0:
            monster_y = plat.top - monster_height
            monster_vel_y = 0
            monster_on_ground = True

    # 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            # 무기 획득
            if not weapon_collected and player_rect.colliderect(weapon_rect) and event.key == pygame.K_e:
                weapon_collected = True
                print("무기 습득!")

            # 무기 장착 / 해제
            if weapon_collected:
                if event.key == pygame.K_1:
                    weapon_equipped = True
                    print("무기 장착")
                if event.key == pygame.K_x:
                    weapon_equipped = False
                    print("무기 해제")

        # 마우스 클릭 공격/방어
        if weapon_equipped and event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                attack_width = 80   # 공격 범위 가로 길이
                attack_height = player_height
                if last_direction == "RIGHT":
                    attack_rect = pygame.Rect(player_x + player_width, player_y, attack_width, attack_height)
                else:
                    attack_rect = pygame.Rect(player_x - attack_width, player_y, attack_width, attack_height)
                
                if attack_rect.colliderect(monster_rect):
                    monster_hp -= 30
                    if monster_hp <= 0:
                        monster_state = False
            elif event.button == 3:
                evasion = True  # 회피


    # 배경 그리기
    screen.blit(background_img, (0, 0))

    # 무기 화면 표시
    if not weapon_collected:
        screen.blit(weapon_img, (weapon_x, weapon_y))

    # 발판 그리기
    for plat in platforms:
        pygame.draw.rect(screen, GREEN, plat)
        # pass                              # 투명색으로 바꿀

    # 몬스터 & 플레이어 그리기
    if monster_state == True:
        screen.blit(monster_img, (monster_x, monster_y))
        draw_monster_health_bar(screen, monster_x, monster_y, monster_hp, monster_max_hp)
    elif monster_state == False:
        pass

    if player_state == True:
        screen.blit(player_img, (player_x, player_y))
        draw_player_health_bar(screen, 50, 50, player_hp, player_max_hp)
    elif player_state == False:
        print("게임 오버")
        running = False
    

    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()
sys.exit()
